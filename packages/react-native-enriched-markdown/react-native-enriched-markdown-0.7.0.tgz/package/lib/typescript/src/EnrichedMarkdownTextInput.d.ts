import { type OnLinkDetected, type OnStartMentionEvent, type OnChangeMentionEvent, type OnEndMentionEvent } from './EnrichedMarkdownTextInputNativeComponent';
export type { OnLinkDetected, OnStartMentionEvent, OnChangeMentionEvent, OnEndMentionEvent, } from './EnrichedMarkdownTextInputNativeComponent';
import type { HostInstance, ViewProps, ViewStyle, TextStyle, ColorValue } from 'react-native';
import type { RefObject } from 'react';
export interface LinkStyle {
    color?: string;
    underline?: boolean;
    backgroundColor?: string;
}
export interface MarkdownTextInputStyle {
    strong?: {
        color?: string;
    };
    em?: {
        color?: string;
    };
    link?: LinkStyle;
    linkVariants?: Record<string, LinkStyle>;
    spoiler?: {
        color?: string;
        backgroundColor?: string;
    };
}
export interface StyleState {
    bold: {
        isActive: boolean;
    };
    italic: {
        isActive: boolean;
    };
    underline: {
        isActive: boolean;
    };
    strikethrough: {
        isActive: boolean;
    };
    spoiler: {
        isActive: boolean;
    };
    link: {
        isActive: boolean;
    };
}
export interface ContextMenuItem {
    text: string;
    onPress: (event: {
        text: string;
        selection: {
            start: number;
            end: number;
        };
        styleState: StyleState;
    }) => void;
    icon?: string;
    visible?: boolean;
}
export interface CaretRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface EnrichedMarkdownTextInputInstance {
    focus: () => void;
    blur: () => void;
    measure: HostInstance['measure'];
    measureInWindow: HostInstance['measureInWindow'];
    measureLayout: HostInstance['measureLayout'];
    setValue: (markdown: string) => void;
    setSelection: (start: number, end: number) => void;
    toggleBold: () => void;
    toggleItalic: () => void;
    toggleUnderline: () => void;
    toggleStrikethrough: () => void;
    toggleSpoiler: () => void;
    setLink: (url: string) => void;
    insertLink: (text: string, url: string) => void;
    insertMention: (displayText: string, url: string) => void;
    startMention: (indicator: string) => void;
    removeLink: () => void;
    getMarkdown: () => Promise<string>;
    getCaretRect: () => Promise<CaretRect>;
}
export interface EnrichedMarkdownTextInputProps extends Omit<ViewProps, 'style' | 'children'> {
    ref?: RefObject<EnrichedMarkdownTextInputInstance | null>;
    defaultValue?: string;
    placeholder?: string;
    placeholderTextColor?: ColorValue;
    editable?: boolean;
    autoFocus?: boolean;
    scrollEnabled?: boolean;
    autoCapitalize?: string;
    multiline?: boolean;
    cursorColor?: ColorValue;
    selectionColor?: ColorValue;
    markdownStyle?: MarkdownTextInputStyle;
    style?: ViewStyle | TextStyle;
    onChangeText?: (text: string) => void;
    onChangeMarkdown?: (markdown: string) => void;
    onChangeSelection?: (selection: {
        start: number;
        end: number;
    }) => void;
    onChangeState?: (state: StyleState) => void;
    onCaretRectChange?: (rect: CaretRect) => void;
    onLinkDetected?: (event: OnLinkDetected) => void;
    mentionIndicators?: string[];
    onStartMention?: (event: OnStartMentionEvent) => void;
    onChangeMention?: (event: OnChangeMentionEvent) => void;
    onEndMention?: (event: OnEndMentionEvent) => void;
    onFocus?: () => void;
    onBlur?: () => void;
    contextMenuItems?: ContextMenuItem[];
    linkRegex?: RegExp | null;
    /**
     * Paragraph writing direction.
     * - `'first-strong'` (default): resolves each paragraph from its first strong
     *   directional character. Neutral-only paragraphs fall back to the view's
     *   resolved layout direction (inherits ancestor `direction` style). Library
     *   extension — matches Android's `TEXT_DIRECTION_FIRST_STRONG`.
     * - `'auto'`: React Native parity. iOS TextKit follows the app's
     *   `userInterfaceLayoutDirection`; mixed-direction paragraphs do not
     *   auto-resolve.
     * - `'ltr'` / `'rtl'`: force base direction on every paragraph.
     *
     * Android ignores this prop; the platform's `EditText` always uses
     * `TEXT_DIRECTION_FIRST_STRONG` per paragraph.
     * @default 'first-strong'
     * @platform ios
     */
    writingDirection?: 'auto' | 'ltr' | 'rtl' | 'first-strong';
}
export declare const EnrichedMarkdownTextInput: ({ ref, markdownStyle, style, defaultValue, placeholder, placeholderTextColor, editable, autoFocus, scrollEnabled, autoCapitalize, multiline, cursorColor, selectionColor, onChangeText, onChangeMarkdown, onChangeSelection, onChangeState, onCaretRectChange, onLinkDetected, mentionIndicators, onStartMention, onChangeMention, onEndMention, onFocus, onBlur, contextMenuItems, linkRegex: _linkRegex, writingDirection, ...rest }: EnrichedMarkdownTextInputProps) => import("react/jsx-runtime").JSX.Element;
export default EnrichedMarkdownTextInput;
//# sourceMappingURL=EnrichedMarkdownTextInput.d.ts.map