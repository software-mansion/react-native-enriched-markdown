import type { MarkdownStyle, Md4cFlags } from '../types/MarkdownStyle';
import type { EnrichedMarkdownTextProps, StreamingConfig, ContextMenuItem, SelectionMenuConfig } from '../types/MarkdownTextProps';
import type { LinkPressEvent, LinkLongPressEvent, TaskListItemPressEvent } from '../types/events';
export type { MarkdownStyle, Md4cFlags };
export type { EnrichedMarkdownTextProps, StreamingConfig, ContextMenuItem, SelectionMenuConfig, };
export type { LinkPressEvent, LinkLongPressEvent, TaskListItemPressEvent };
export declare const EnrichedMarkdownText: ({ markdown, markdownStyle, containerStyle, onLinkPress, onLinkLongPress, onTaskListItemPress, enableLinkPreview, selectable, md4cFlags, allowFontScaling, maxFontSizeMultiplier, allowTrailingMargin, flavor, streamingAnimation, streamingConfig, spoilerOverlay, contextMenuItems, selectionMenuConfig, selectionColor, selectionHandleColor, textBreakStrategy, lineBreakStrategyIOS, writingDirection, ...rest }: EnrichedMarkdownTextProps) => import("react/jsx-runtime").JSX.Element;
export default EnrichedMarkdownText;
//# sourceMappingURL=EnrichedMarkdownText.d.ts.map